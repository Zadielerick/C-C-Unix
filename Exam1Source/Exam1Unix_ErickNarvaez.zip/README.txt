In order to compile on Ubuntu, run the following command: 

g++ -std=c++11 Exam1.cpp Square.cpp Circle.cpp Hexagon.cpp 